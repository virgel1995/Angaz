const UserAuthController = require('./auth')
const UserSettingsController = require('./settings')




exports.UserAuthController = UserAuthController
exports.UserSettingsController = UserSettingsController