const admin = "admin",
    freelancer = "freelancer",
    client = "client",
    both = "both"

// const endPoints = {
//     allUsers: [admin],
//     updateMobile: [freelancer, client, both],
//     updateProfilePic: [freelancer, client, both],
//     register: [admin]
// }

// module.exports = endPoints

module.exports = {
    admin,
    freelancer,
    client,
    both
}