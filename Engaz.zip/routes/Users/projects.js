const router = require("express").Router()




router.post('/create', (req, res) => {
    res.send('create Project ')
})


module.exports = router